import "./App.css";

import Mainroutes from "./Components/Routes/MainRoutes";
function App() {
  return (
    <div className="App">
    <Mainroutes/>
    </div>
  );
}
export default App;

