
export const Home = ()=>{
    return <h1>Home</h1>
}